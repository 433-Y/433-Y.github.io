#include <stdio.h>
#include <string.h>
char str[105];
int n;
int main() {
    scanf("%s%d", str, &n);
    for (int i = 0; i < strlen(str); i++) str[i] < 'a' ? printf("%c", (str[i] - 'A' + n) % 26 + 'A') : printf("%c", (str[i] - 'a' + n) % 26 + 'a');
    return 0;
}
