#include <stdio.h>
#include <string.h>
char str[105];
int judge;
int main() {
    gets(str);
    char aim = getchar();
    for (int i = 0; i < strlen(str); i ++) {
        if (str[i] == aim) {
            str[i] = ' ';
            judge = 1;
        }
    }
    if (!judge) printf("NotFound");
    else for (int i = 0; i < strlen(str); i++) if (str[i] != ' ') printf("%c", str[i]);
    return 0;
}
