#include <stdio.h>
int arr[100], n, cnt;
int gcd(int a, int b) {
    return b ? gcd(b, a % b) : a;
}
int main() {
    while (1) {
        scanf("%d", &n);
        if (!n) break;
        arr[cnt++] = n;
    }
    int g = arr[0];
    for (int i = 1; i < cnt; i++) g = gcd(g, arr[i]);
    printf("%d\n", g);
    for (int i = 0; i < cnt; i++) i ? printf(" %d", arr[i]) : printf("%d", arr[i]);
    return 0;
}
