#include <stdio.h>
#include <string.h>
char str[205];
int cnt, n;
int main() {
    scanf("%s%d", str, &n);
    for (int i = 0; i < strlen(str); i++) {
        if (str[i] == '*') cnt ++;
        else cnt = 0;
    }
    if (cnt > n) for (int i = 0; i < strlen(str) - cnt + n; i++) printf("%c", str[i]);
    else printf(str);
    return 0;
}
