#include <stdio.h>
int vis[10005], n, x, cnt;
int main() {
    for (int k = 0; k < 2; k++) {
        scanf("%d", &n);
        for (int i = 0; i < n; i++) scanf("%d", &x), !k ? vis[x] = 1 : (vis[x] = vis[x] ? 2 : 1);
    }
    for (int i = 1; i < 10005; i++) if (vis[i] == 2) printf("%s%d", cnt++ ? " " : "", i);
    return 0;
}