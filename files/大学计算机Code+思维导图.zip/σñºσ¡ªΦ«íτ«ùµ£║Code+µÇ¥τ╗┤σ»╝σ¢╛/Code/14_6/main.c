#include <stdio.h>
int n, vis[6005];
int main() {
    scanf("%d", &n);
    int sum = n, i = 0;
    while (sum > 3) {
        int cnt = 1, flag = i++ % 2 ? 3 : 2;
        for (int j = 1; j < n; j++) if (!vis[j]) if (++cnt % flag == 0) vis[j] = 1, sum--;
    }
    for (int k = 0; k < n; k++) if (!vis[k]) printf("%s%d", k ? " " : "", k + 1);
    return 0;
}