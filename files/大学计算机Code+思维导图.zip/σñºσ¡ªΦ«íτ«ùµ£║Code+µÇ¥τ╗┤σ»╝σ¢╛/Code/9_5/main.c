#include <stdio.h>
int n, num[100005], m, MAXN = -100000;
int main() {
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &m);
        num[m]++;
        if (MAXN < m) MAXN = m;
    }
    printf("%d,%d", MAXN, num[MAXN]);
    return 0;
}