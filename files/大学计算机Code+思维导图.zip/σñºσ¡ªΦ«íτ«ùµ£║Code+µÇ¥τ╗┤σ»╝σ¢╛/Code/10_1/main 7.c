#include <stdio.h>
int ispalindrome(int n) {
    int pow[100], cnt = -1, judge = 1;
    while (n) {
        pow[++cnt] = n % 10;
        n /= 10;
    }
    for (int i = 0; i < cnt / 2 + 1; i++) if (pow[i] != pow[cnt - i]) judge = 0;
    return judge;
}
int main() {
    int n, cnt = 0;
    scanf("%d", &n);
    for (int i = 1000; i <= n; i++) if (ispalindrome(i)) cnt++ ? printf(" %d", i) : printf("%d", i);
    return 0;
}
