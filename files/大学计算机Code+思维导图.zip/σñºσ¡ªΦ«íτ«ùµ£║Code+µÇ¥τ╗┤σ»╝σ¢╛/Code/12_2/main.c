#include <stdio.h>
int n, m[100], cnt;
int main() {
    scanf("%d", &n);
    while (n) {
        m[++cnt] = n % 1000;
        n /= 1000;
    }
    for (int i = cnt; i; i--) cnt == i ? printf("%d", m[i]) : printf(",%d", m[i]);
    return 0;
}
