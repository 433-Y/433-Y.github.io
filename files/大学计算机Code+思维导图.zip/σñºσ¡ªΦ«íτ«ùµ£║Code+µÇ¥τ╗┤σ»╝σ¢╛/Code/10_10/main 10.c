#include <stdio.h>
#include <string.h>
char latter[205];
int main() {
    scanf("%s", latter);
    for (int i = 1; i < strlen(latter) - 1; i++)
        for (int j = 1; j < strlen(latter) - i - 1; j++)
            if (latter[j] < latter[j + 1] ) {
                char tmp = latter[j + 1];
                latter[j + 1] = latter[j];
                latter[j] = tmp;
            }
    for (int i = 0; i < strlen(latter); i++) printf("%c", latter[i]);
    return 0;
}
