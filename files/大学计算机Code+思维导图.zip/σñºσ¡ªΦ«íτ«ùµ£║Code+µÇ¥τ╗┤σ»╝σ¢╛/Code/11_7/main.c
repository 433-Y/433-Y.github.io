#include <stdio.h>
int n, num[100], l, r, st, ed;
int main() {
    scanf("%d", &n);
    for (int i = 0; i < n; i++) scanf("%d", &num[i]);
    for (int i = 0; i < n; i++) {
        st = i;
        for (int j = i; j < n; j++) {
            if (num[j] == num[st]) ed = j, i = j;
            else break;
        }
        if (ed - st > r - l) l = st, r = ed;
    }
    if (!r) printf("NO");
    else printf("%d,%d", l, r);
    return 0;
}
