#include <stdio.h>
#include <string.h>
char n[1000];
int main() {
    scanf("%s", n);
    for (int i = 0; i < strlen(n); i++) i % 2 ? printf("%c", n[strlen(n) / 2 * 2 - i]) : printf("%c", n[i]);
    return 0;
}
