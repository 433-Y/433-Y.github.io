#include <stdio.h>
int main() {
    int n;
    scanf("%d", &n);
    printf("%d %d", (n / 100) % 10000, (n / 100) % 10000 + 1024);
    return 0;
}
