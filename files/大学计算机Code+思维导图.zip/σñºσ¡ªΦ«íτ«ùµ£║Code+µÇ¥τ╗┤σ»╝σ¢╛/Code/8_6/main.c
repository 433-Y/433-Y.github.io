#include <stdio.h>

int main() {
    int n;
    double sum = 0, sgn = 1;
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) {
        sum += sgn / (2 * i - 1);
        sgn *= -1;
    }
    printf("%lf", sum);
    return 0;
}
