#include <stdio.h>

int main() {
    float a, b, c, d;
    scanf("%f%f%f", &a, &b, &c);
    d = a + b + c;
    int D = (int)(d + 0.5);
    printf("%g %d", d, D);
    return 0;
}
