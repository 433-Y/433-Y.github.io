#include <stdio.h>
int num, cnt, sum, MAXN = -1000000, MINN = 100000;
int main() {
    scanf("%d", &cnt);
    for (int i = 0; i < cnt; i++) {
        scanf("%d", &num);
        if (MAXN < num) MAXN = num;
        if (MINN > num) MINN = num;
        sum += num;
    }
    printf("%d %d %f", MAXN, MINN,  1.0 * sum / cnt);
    return 0;
}
