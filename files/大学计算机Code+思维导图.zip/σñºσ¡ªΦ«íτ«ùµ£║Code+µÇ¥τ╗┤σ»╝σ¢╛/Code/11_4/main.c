#include <stdio.h>
int n, cnt, po[100];
int main() {
    scanf("%d", &n);
    n /= 2;
    printf("%d ", n);
    while (n) {
        po[++cnt] = n % 10;
        n /= 10;
    }
    for (int i = cnt; i; i--) printf("%c", po[i] + 'a');
    return 0;
}
