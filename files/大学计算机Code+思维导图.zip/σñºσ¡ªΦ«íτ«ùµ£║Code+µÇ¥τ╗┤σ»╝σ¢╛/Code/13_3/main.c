#include <stdio.h>
#include <string.h>
char latter[10][10] = {"zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"}, str[100];
int cnt;
int main() {
    scanf("%s", str);
    for (int i = 0; i < strlen(str); i++) printf("%s%s", cnt++ ? " " : "", latter[str[i] - '0']);
    return 0;
}
