#include <stdio.h>
#include <ctype.h>
#include <string.h>
char str[205];
int times[26], cnt;
int main() {
    gets(str);
    for (int i = 0; i < strlen(str); i++) {
        if (str[i] >= 'A' && str[i] <= 'Z') times[str[i] - 'A'] ++;
        if (str[i] >= 'a' && str[i] <= 'z') times[str[i] - 'a'] ++;
    }
    for (int j = 0; j < 26; j++) printf("%s%d", cnt++ ? "," : "", times[j]);
    return 0;
}
