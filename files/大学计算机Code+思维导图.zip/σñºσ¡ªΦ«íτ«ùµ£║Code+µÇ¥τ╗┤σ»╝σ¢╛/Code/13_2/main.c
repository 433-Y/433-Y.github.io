#include <stdio.h>
int n;
struct person{char id[10000], name[1000]; int s1, s2, s3, sum;} a[1000], tmp;
int main() {
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%s %s %d %d %d", a[i].id, a[i].name, &a[i].s1, &a[i].s2, &a[i].s3);
        a[i].sum = a[i].s1 + a[i].s2 +a[i].s3;
    }
    for (int i = 0; i < n - 1; i++)
        for (int j = 0; j < n - i - 1; j++)
            if (a[j].sum > a[j + 1].sum)
                tmp = a[j], a[j] = a[j + 1], a[j + 1] = tmp;
    for (int i = 0; i < n; i++) printf("%s %s %d %d %d %d\n", a[i].id, a[i].name, a[i].s1, a[i].s2, a[i].s3, a[i].sum);
    return 0;
}
