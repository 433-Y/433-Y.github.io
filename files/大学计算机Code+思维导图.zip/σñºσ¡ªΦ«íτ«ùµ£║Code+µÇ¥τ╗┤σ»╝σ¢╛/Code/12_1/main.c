#include <stdio.h>
#include <string.h>
char arr[100];
int main() {
    gets(arr);
    int l = 0, r = strlen(arr) - 1;
    while (arr[l] == ' ') l++;
    while (arr[r] == ' ') r--;
    for (int i = 0; i < strlen(arr); i++) if (!(arr[i] == ' ' && i > l && i < r)) printf("%c", arr[i]);
    return 0;
}
