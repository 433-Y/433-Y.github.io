#include <stdio.h>
int sum[5];
int main() {
    int n;
    while (1) {
        scanf("%d", &n);
        if (n == -1) break;
        if (n == -1 || n == 1 || n == 2 || n == 3) sum[n]++;
        else sum[4]++;
    }
    printf("%d %d %d %d", sum[1], sum[2], sum[3], sum[4]);
    return 0;
}
