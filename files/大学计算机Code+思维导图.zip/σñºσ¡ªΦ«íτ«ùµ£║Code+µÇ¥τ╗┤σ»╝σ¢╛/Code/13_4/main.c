#include <stdio.h>
#include <string.h>
int vis[26], cnt[105][26], tot, k;
char str[105];
int main() {
    gets(str);
    for (int i = 0; i < strlen(str); i++)
        if ((str[i] >= 'a' && str[i] <= 'z') || (str[i] >= 'A' && str[i] <= 'Z')) {
            tot++;
            str[i] >= 'a' && str[i] <= 'z' ? (vis[str[i] - 'a']++) : (vis[str[i] - 'A']++);
        }
    for (int i = 0; i < 26; i++) cnt[vis[i]][i] = 1;
    for (int i = tot; i + 1; i--)
        for (int j = 0; j < 26; j++)
            if (cnt[i][j]) printf("%s%c-%d", k++ ? " " : "", j + 'A', i);
    return 0;
}