#include <stdio.h>
int n;
int main() {
    scanf("%d", &n);
    printf("1");
    for (int i = 2; i <= n; i++)
        if (n % i == 0) {
            n /= i;
            printf("*%d", i);
            i--;
        }
    return 0;
}
