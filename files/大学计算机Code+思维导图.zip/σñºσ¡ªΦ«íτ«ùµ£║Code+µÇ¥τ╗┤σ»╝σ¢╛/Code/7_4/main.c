#include <stdio.h>

int main() {
    int a, b, c;
    scanf("%d%d%d", &a, &b, &c);
    float d = (a + b + c);
    d /= 3;
    printf("%g", d);
    return 0;
}
