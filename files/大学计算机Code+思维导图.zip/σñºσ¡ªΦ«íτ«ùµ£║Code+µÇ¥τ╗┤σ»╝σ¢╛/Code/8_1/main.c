#include <stdio.h>
#include <math.h>
int main() {
    int n;
    while (1) {
        scanf("%d", &n);
        if (n > 0 && n <= 1000) {
            printf("%d", sqrt(n));
            break;
        } else printf("0\n");
    }
    return 0;
}
