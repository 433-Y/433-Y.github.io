#include <stdio.h>
int n, K, cnt;
char ans[105];
int main() {
    scanf("%d %d", &n, &K);
    do {
        ans[cnt++] = (n % K) > 9 ? 'A' + n % K - 10 : n % K + '0';
        n /= K;
    } while (n);
    for (int i = cnt - 1; ~i; i--) printf("%c", ans[i]);
    return 0;
}
