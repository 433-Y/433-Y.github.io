#include <stdio.h>
int n, m, arr[1000];
int main() {
    scanf("%d%d", &n, &m);
    for (int i = 0; i < n; i++) scanf("%d", &arr[(i + m) % n]);
    for (int i = 0; i < n; i++) i ? printf(" %d", arr[i]) : printf("%d", arr[i]);
    return 0;
}
