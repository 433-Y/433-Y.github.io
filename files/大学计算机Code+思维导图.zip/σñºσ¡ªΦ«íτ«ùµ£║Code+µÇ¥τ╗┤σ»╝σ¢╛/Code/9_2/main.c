#include <stdio.h>
int n;
int main() {
    scanf("%d", &n);
    for (int i = 1; i < n; i++) {
        int sum = 0, j = i, judge = 0;
        while (sum < n) {
            sum += j;
            j++;
            if (sum == n) judge = 1;
        }
        if (judge) {
            printf("%d=", n);
            int s = 0, cnt = 0;
            while (s < n) {
                cnt++ ? printf("+%d", i + cnt - 1) : printf("%d", i + cnt - 1);
                s += i + cnt;
            }
            printf("\n");
        }
    }
    return 0;
}
