#include <stdio.h>
char c;
int num, sum, cnt;
int read_int() {
    do {
        if (c == 10) return -1;
    } while ((c = getchar()) < '0' || c >= '9');
    int x = c ^ 48;
    while((c = getchar()) >= '0' && c <= '9') x = (x << 3) + (x << 1) + (c ^ 48);
    return x;
}
int main() {
    while(~(num = read_int())){
        printf("%s%d", cnt++ ? " " : "", num);
        sum += num;
    }
    if(cnt) printf("\n%d\n", sum);
    else printf("NO");
    return 0;
}
