#include <stdio.h>
#include <string.h>
char str[105];
int main() {
    scanf("%s", str);
    for (int i = 0; i / 2 < strlen(str) / 2; i++) {
        if (i % 2 == 0)
            for (int j = 0; j / 2 < (strlen(str) - i) / 2 - 1; j++)
                if (j % 2 == 0 && str[j] > str[j + 2]) {
                    char tmp = str[j];
                    str[j] = str[j + 2];
                    str[j + 2] = tmp;
                }
    }
    for (int i = 0; i < strlen(str); i++) printf("%c", str[i]);
    return 0;
}
