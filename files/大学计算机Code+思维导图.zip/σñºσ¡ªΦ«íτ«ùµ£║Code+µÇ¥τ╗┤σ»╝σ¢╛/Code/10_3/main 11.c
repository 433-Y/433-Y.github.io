#include <stdio.h>
#include <string.h>
char str[105];
int main() {
    scanf("%s", str);
    int maxid = str[0], times = 1, cnt = 1, maxpos = 1;
    for (int i = 1; i <= strlen(str); i++) {
        if (str[i] != str[i - 1]) {
            if (cnt > times) {
                times = cnt;
                maxid = str[i - 1];
                maxpos = i - cnt;
            }
            cnt = 1;
        } else cnt ++;
    }
    printf("%c %d %d", maxid, times, maxpos);
    return 0;
}
