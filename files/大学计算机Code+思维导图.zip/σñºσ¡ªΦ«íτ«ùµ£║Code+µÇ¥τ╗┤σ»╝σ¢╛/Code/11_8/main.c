#include <stdio.h>
double h = 100, sum = -100;
int n;
int main() {
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        sum += h * 2;
        h /= 2;
    }
    printf("%lf\n%lf", sum, h);
    return 0;
}
