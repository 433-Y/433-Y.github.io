#include <stdio.h>

int main() {
    int n, m[4];
    scanf("%d", &n);
    for (int i = 0, j = 1; i < 4; i++) {
       m[i] = ((n + 5) % 10);
       n /= 10;
       printf("%d", m[i]);
    }
    return 0;
}
