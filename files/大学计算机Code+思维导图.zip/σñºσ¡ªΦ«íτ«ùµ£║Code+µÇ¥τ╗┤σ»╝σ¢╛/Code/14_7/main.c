#include <stdio.h>
int vis[10005][2], n, x, cnt;
int main() {
    for (int k = 0; k < 2; k++) {
        scanf("%d", &n);
        for (int i = 0; i < n; i++) scanf("%d", &x), vis[x][k]++;
    }
    for (int i = 0; i < 10005; i++) if (!(vis[i][0] && vis[i][1]) && vis[i][0] | vis[i][1]) printf("%s%d", cnt++ ? " " : "", i), vis[i][0] ? vis[i--][0]-- : vis[i--][1]--;
    return 0;
}