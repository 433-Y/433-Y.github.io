#include <stdio.h>
#include <string.h>
int vis[128];
char str[100];
int main() {
    scanf("%s", str);
    for (int i = 0; i < strlen(str); i++) if (str[i] >= 'a' && str[i] <= 'z') vis[str[i]]++;
    for (int i = 0; i < 128; i++)
        if (vis[i]) {
            vis[i]--;
            printf("%c", i--);
        }
    return 0;
}
