#include <stdio.h>
#include <string.h>
char str[105];
int main() {
    gets(str);
    int l = 0, r = strlen(str) - 1;
    while (str[l] == '*') l++;
    while (str[r] == '*') r--;
    for (int i = 0; i < strlen(str); i++) if (!(str[i] == '*' && i >= l && i <= r)) printf("%c", str[i]);
    return 0;
}
