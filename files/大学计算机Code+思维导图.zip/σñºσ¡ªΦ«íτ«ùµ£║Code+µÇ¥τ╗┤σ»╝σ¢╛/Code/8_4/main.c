#include <stdio.h>
int m, n, cnt;
int main() {
    scanf("%d %d", &m, &n);
    for (int i = m, pow = 1; i <= n; i ++) {
        while (i / pow) pow *= 10;
        if ((i * i - i) % pow == 0) {
            if (cnt ++ ) printf(" ");
            printf("%d", i);
        }
    }
    return 0;
}
