#include <stdio.h>
char l;
int main() {
    scanf("%c", &l);
    printf("%c%c%c", (l - 'A' + 25) % 26 + 'A', l, (l - 'A' + 1) % 26 + 'A');
    return 0;
}
