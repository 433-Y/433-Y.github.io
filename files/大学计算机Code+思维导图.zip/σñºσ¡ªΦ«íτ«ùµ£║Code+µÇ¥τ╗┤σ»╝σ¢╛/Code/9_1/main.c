#include <stdio.h>
int n, cnt[5];
int main() {
    while (n != -1) {
        scanf("%d", &n);
        if (n != -1) cnt[n]++;
    }
    for (int i = 0; i < 5; i++) printf("%s%d", i ? " " : "", cnt[i]);
    return 0;
}