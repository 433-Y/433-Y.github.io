#include <stdio.h>
#include <string.h>
char str[21], s[21][105];
int cnt, sum[105];
int main() {
    while (scanf("%s", str) && strcmp(str, "###")) {
        int judge = 0;
        for (int i = 0; i < cnt; i++) {
            if (strcmp(str, s[i]) == 0) {
                sum[i]++, judge = 1;
                break;
            }
        }
        if (!judge) strcpy(s[cnt++], str);
    }
    for (int i = 0; i < cnt; i++) printf("%s%s-%d", i ? " ": "", s[i], sum[i] + 1);
    return 0;
}