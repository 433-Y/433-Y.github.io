#include <stdio.h>

int main() {
    int m, n;
    scanf("%d%d", &m, &n);
    for (int i = m; i <= n; i++) {
        int tmp = i;
        if (!(tmp % 7)) printf("%d是7的倍数\n", i);
        while (tmp) {
            if (tmp % 10 == 7) {
                printf("%d是带7的数\n", i);
                break;
            }
            tmp /= 10;
        }
    }
    return 0;
}
