#include <stdio.h>
#include <string.h>
char str[1005], minn[1005], maxn[1005];
int main() {
    memset(minn, -1, sizeof(minn));
    for (int i = 0; i < 5; i++) {
        memset(str, 0, sizeof(str));
        scanf("%s", str);
        if(strcmp(str, maxn) > 0) memcpy(maxn, str, sizeof(str));
        if(strcmp(str, minn) < 0) memcpy(minn, str, sizeof(str));
    }
    printf("max:%s min:%s", maxn, minn);
    return 0;
}
