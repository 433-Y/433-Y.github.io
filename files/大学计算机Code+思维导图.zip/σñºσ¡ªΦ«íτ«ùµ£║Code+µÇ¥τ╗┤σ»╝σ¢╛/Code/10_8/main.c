#include <stdio.h>
#include <string.h>
char str[105], aim;
int judge;
int main() {
    gets(str);
    aim = str[strlen(str) - 1];
    for (int i = 0; i < strlen(str) - 2; i++) {
        if (str[i] == aim) {
            printf("%d", i);
            judge = 1;
            break;
        }
    }
    if (!judge) printf("-1");
    return 0;
}
