#include <stdio.h>
char latter[10000];
int main() {
    scanf("%s", latter);
    for (int i = 0; latter[i] != 0; i++) {
        printf("%c %d %c\n", latter[i], latter[i], latter[i] + 1);
    }
    return 0;
}
