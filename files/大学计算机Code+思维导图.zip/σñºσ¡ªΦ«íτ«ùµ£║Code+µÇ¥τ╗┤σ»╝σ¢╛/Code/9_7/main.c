#include <stdio.h>
#include <string.h>
char latter[205];
int l;
int main() {
    scanf("%s", latter);
    while (latter[l] == '*') l++;
    for (int i = l; i < strlen(latter) + l; i++) printf("%c", i < strlen(latter) ? latter[i] : '*');
    return 0;
}