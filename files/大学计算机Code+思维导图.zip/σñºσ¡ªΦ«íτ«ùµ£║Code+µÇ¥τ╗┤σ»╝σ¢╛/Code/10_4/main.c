#include <stdio.h>
int Judge(int x) {
    int judge = 0;
    if ((x % 100 == 0 && x % 400 == 0) || (x % 100 && x % 4 == 0)) judge = 1;
    return judge;
}
int years, cnt, K;
int main() {
    scanf("%d %d", &years, &K);
    while (cnt < K) if (Judge(years++)) cnt++;
    printf("%d", years - 1);
    return 0;
}
