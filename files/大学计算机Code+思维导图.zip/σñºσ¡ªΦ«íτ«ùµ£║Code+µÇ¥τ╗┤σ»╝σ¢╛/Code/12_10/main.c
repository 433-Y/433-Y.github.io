#include <stdio.h>
double d, v;
int times, cnt;
int main() {
    scanf("%lf%lf", &d, &v);
    times = (int)(v / d) + 1;
    for (cnt = 1; cnt * (cnt + 1) + 2 > 2 * times || 2 * times > (cnt + 2) * (cnt + 1); cnt++);
    printf("%d", cnt + times);
    return 0;
}
