#include <stdio.h>

int month[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
int main() {
    int x ,y, z = 0;
    scanf("%d,%d", &x, &y);
    if (x % 100 == 0) {
        if (x % 400 == 0) month[1] = 29;
    } else
        if (x % 4 == 0) month[1] = 29;
    printf("%d", month[y - 1]);
    return 0;
}
