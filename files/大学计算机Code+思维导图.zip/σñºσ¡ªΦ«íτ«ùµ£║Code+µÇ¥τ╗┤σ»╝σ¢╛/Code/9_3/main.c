#include <stdio.h>
int main() {
    int a, n, sum = 0, tmp;
    scanf("%d%d", &a, &n);
    tmp = a;
    for (int i = 1; i <= n; i++) {
        for (int j = 0; j < i; j++) printf("%d", a);

        sum += tmp * (n - i + 1);
        tmp *= 10;
        i == n ? printf("=%d", sum) : printf("+");
    }
    return 0;
}
