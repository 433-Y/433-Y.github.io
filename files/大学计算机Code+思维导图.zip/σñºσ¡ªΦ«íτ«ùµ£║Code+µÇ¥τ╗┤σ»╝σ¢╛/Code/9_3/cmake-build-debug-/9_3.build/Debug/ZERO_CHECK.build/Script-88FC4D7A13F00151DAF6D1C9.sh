#!/bin/sh
set -e
if test "$CONFIGURATION" = "Debug"; then :
  cd /Users/yangjiayu/Desktop/Code/c/cpp/daji/9_3/cmake-build-debug-
  make -f /Users/yangjiayu/Desktop/Code/c/cpp/daji/9_3/cmake-build-debug-/CMakeScripts/ReRunCMake.make
fi
if test "$CONFIGURATION" = "Release"; then :
  cd /Users/yangjiayu/Desktop/Code/c/cpp/daji/9_3/cmake-build-debug-
  make -f /Users/yangjiayu/Desktop/Code/c/cpp/daji/9_3/cmake-build-debug-/CMakeScripts/ReRunCMake.make
fi
if test "$CONFIGURATION" = "MinSizeRel"; then :
  cd /Users/yangjiayu/Desktop/Code/c/cpp/daji/9_3/cmake-build-debug-
  make -f /Users/yangjiayu/Desktop/Code/c/cpp/daji/9_3/cmake-build-debug-/CMakeScripts/ReRunCMake.make
fi
if test "$CONFIGURATION" = "RelWithDebInfo"; then :
  cd /Users/yangjiayu/Desktop/Code/c/cpp/daji/9_3/cmake-build-debug-
  make -f /Users/yangjiayu/Desktop/Code/c/cpp/daji/9_3/cmake-build-debug-/CMakeScripts/ReRunCMake.make
fi

