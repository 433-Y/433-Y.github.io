#include <stdio.h>
#include <string.h>
char c;
int ans = 0;
int main() {
    while (~(c = getchar()) && c != '\r' && c != '\n'){
        if (c != '0' && c != '1') {
            printf("该字符串不是正确的IP地址");
            return 0;
        }
        ans = ans << 1 | c - '0';
    }
    unsigned char a[4];
    memcpy(a, &ans, 4);
    for (int i = 4; i; i--) printf("%d%c", a[i - 1], i - 1 ? '.' : '\n');
    return 0;
}
