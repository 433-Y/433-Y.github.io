#include <stdio.h>
int m, n, cnt;
int main() {
    scanf("%d%d", &m, &n);
    for (int i = m; i <= n; i++)
        for (int j = i; j <= n; j++)
            for (int k = j; k <= n; k++)
                if (i * i + j * j == k * k) cnt++;
    printf("%d", cnt);
    return 0;
}