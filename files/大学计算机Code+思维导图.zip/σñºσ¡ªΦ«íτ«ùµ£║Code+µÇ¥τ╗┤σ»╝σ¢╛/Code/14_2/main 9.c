#include <stdio.h>
int n, po[100], cnt;
int main() {
    scanf("%d", &n);
    n *= 30;
    printf("%d ", n / 10);
    while (n /= 10) po[cnt++] = n % 10;
    for (int i = 0; i < cnt - 1; i++)
        for (int j = 0; j < cnt - i - 1; j++)
            if (po[j] < po[j + 1]) {
                int tmp = po[j];
                po[j] = po[j + 1];
                po[j + 1] = tmp;
            }
    for (int i = 0; i < cnt; i++) printf("%d", po[i]);
    return 0;
}