#include <stdio.h>
#include <string.h>
char str[205];
int main() {
    scanf("%s", str);
    int l = 0, r = strlen(str) - 1;
    while (str[l] == '*') l++;
    while (str[r] == '*') r--;
    str[r] = 0;
    printf("%s", str + l);
    return 0;
}
