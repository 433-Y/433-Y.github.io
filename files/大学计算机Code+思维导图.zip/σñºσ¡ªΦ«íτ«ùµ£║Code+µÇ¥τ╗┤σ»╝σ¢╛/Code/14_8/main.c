#include <stdio.h>
int n;
typedef struct {
    int a, b;
}Frac;
int gcd(int a, int b) {
    return b ? gcd(b, a % b) : a;
}
Frac plus(Frac x, Frac y) {
    int m = x.a * y.b + x.b * y.a, n = x.b * y.b;
    Frac ans = {m / gcd(m, n), n / gcd(m, n)};
    return ans;
}
Frac x, y = {0, 1};
int main() {
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d/%d", &x.a, &x.b);
        y = plus(y, x);
    }
    y.b == 1 ? (printf("%d", y.a)) : (y.a / y.b ? (y.a > 0 ? printf("%d %d/%d", y.a / y.b, y.a % y.b, y.b) : printf("-%d %d/%d", - y.a / y.b, (-y.a) % y.b, y.b)) : printf("%d/%d", y.a, y.b));
    return 0;
}
