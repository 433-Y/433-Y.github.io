#include <stdio.h>
#include <string.h>
char str[10005];
int main() {
    gets(str);
    for (int i = strlen(str) - 1; ~i; i--) printf("%s%s", str + i, i ? " " : "");
    return 0;
}