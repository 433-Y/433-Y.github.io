#include <stdio.h>
#include <string.h>
char str[105], aim[105];
int cnt = 0;
int main() {
    scanf("%s %s", str, aim);
    for (int i = 0; i <= strlen(str) - strlen(aim); i++) {
        int judge = 1;
        for (int j = 0; j < strlen(aim); j++) if (aim[j] != str[i + j]) judge = 0;
        if (judge) cnt++;
    }
    printf("%d", cnt);
    return 0;
}
