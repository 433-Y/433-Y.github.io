#include <stdio.h>
int x, y, wei[1000];
void init() {
    int po = 1;
    for (int i = 0; i < 100; i++) wei[i] = po, po *= 10;
}
int reverse(int n) {
    int ans = 0, cnt = 0, pow[1000];
    while (n) pow[cnt++] = n % 10, n /= 10;
    for (int i = 0; i < cnt; i++) ans +=  wei[cnt - i - 1] * pow[i];
    return ans;
}
int main() {
    init();
    scanf("%d%d", &x, &y);
    int a = (x + y) >> 1, b = (x - y) >> 1;
    printf("%d %d", reverse(a) + reverse(b), reverse(a) - reverse(b));
    return 0;
}
