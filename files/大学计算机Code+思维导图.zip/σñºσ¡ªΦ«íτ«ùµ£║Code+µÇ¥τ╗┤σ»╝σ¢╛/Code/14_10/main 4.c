#include <stdio.h>
#include <string.h>
char s[105], t[105];
int vis[128];
int main() {
    scanf("%s %s", s, t);
    for (int i = 0; i < strlen(s); i++) (s[i] >=  'a' && s[i] <= 'z') ? (vis[s[i] - 'a' + 'A'] = 1) : (vis[s[i]] = 1);
    for (int i = 0; i < strlen(t); i++) (t[i] >=  'a' && t[i] <= 'z') ? (vis[t[i] - 'a' + 'A'] = 1) : (vis[t[i]] = 1);
    for (int i = 0; i < 128; i++) if (vis[i]) printf("%c", i);
    return 0;
}
