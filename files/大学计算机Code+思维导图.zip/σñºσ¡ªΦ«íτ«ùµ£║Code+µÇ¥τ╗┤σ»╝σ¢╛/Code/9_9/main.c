#include <stdio.h>

int main() {
    int n;
    double a = 2, b = 1, sum = 0;
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        sum += a / b;
        double tmp = a;
        a += b;
        b = tmp;
    }
    printf("%.4f", sum);
    return 0;
}
