#include <stdio.h>
int n, num[10005], tmp;
int main() {
    scanf("%d", &n);
    for (int i = 0; i < n; i++) scanf("%d", &num[i]);
    for (int i = 0; i < n - 1; i++)for (int j = 0; j < n - i - 1; j++)if (num[j] > num[j + 1])tmp = num[j], num[j] = num[j + 1], num[j + 1]  = tmp;
    tmp = num[n / 2], num[n / 2] = num[n - 1], num[n - 1] = tmp;
    for (int i = 0; i < n; i++) printf("%s%d", i ? " " : "", (i == 0 || i == n / 2 || i == n - 1) ? num[i] : 0);
    return 0;
}
