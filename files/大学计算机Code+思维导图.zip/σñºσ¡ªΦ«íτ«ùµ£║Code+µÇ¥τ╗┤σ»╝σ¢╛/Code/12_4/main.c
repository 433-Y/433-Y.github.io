#include <stdio.h>
#include <string.h>
char str[105];
int times[128];
int main() {
    scanf("%s", str);
    for (int i = 0; i < strlen(str); i++) if (!times[str[i]]++) printf("%c", str[i]);
    return 0;
}
