#include <stdio.h>

int main() {
    int a, b;
    scanf("%d%d", &a, &b);
    a * a + b * b >= 100 ? printf("%d", (a * a + b * b) / 100) : printf("%d", a * a + b * b);
    return 0;
}
