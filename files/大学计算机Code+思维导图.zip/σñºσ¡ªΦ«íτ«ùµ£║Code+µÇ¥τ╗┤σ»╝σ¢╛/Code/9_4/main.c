#include <stdio.h>
int m, n, cnt;
int main() {
    scanf("%d%d", &m, &n);
    for (int i = m; i < n; i++){
        int x = i % 10, y = (i / 10) % 10, z = (i / 100) % 10;
        if (x * x * x + y * y * y + z * z * z == i) printf("%s%d", cnt++ ? " " : "", i);
    }
    if(!cnt) printf("-1");
    return 0;
}
