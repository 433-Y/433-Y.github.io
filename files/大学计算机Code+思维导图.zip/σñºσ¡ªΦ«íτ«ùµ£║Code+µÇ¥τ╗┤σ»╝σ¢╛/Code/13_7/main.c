#include <stdio.h>
#include <string.h>
char arr[104];
int main() {
    gets(arr);
    for (int i = 0; i < strlen(arr); i++) if (arr[i] >= 'a' && arr[i] <= 'z') printf("%c", arr[i]);
    return 0;
}
