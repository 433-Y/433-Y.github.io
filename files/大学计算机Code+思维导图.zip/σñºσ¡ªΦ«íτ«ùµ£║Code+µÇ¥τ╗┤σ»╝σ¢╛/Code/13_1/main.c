#include <stdio.h>
#include <string.h>
int n;
struct nam {char id[100], name[100];} a[100], tmp;
int main() {
    scanf("%d", &n);
    for (int i = 0; i < n; i++) scanf("%s%s", a[i].name, a[i].id);
    for (int i = 0; i < n - 1; i++) for (int j = 0; j < n - i - 1; j++) if (strcmp(a[j].name, a[j + 1].name) > 0) tmp = a[j], a[j] = a[j + 1], a[j + 1] = tmp;
    for (int i = 0; i < n; i++) printf("%s %s\n", a[i].name, a[i].id);
    return 0;
}