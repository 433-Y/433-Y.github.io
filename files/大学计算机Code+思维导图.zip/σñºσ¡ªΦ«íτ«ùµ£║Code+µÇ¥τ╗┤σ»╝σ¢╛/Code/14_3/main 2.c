#include <stdio.h>
int n, beg, en;
typedef struct t {
    int h, m, s;
}T;
T MAXN = { 0, 0, 0 }, MINN = { 23, 59, 59 };
char id[100][20];
int cmp(T x, T y) {
    return (x.h < y.h || (x.h == y.h && x.m < y.m) || (x.h == y.h && x.m == y.m && x.s <= y.s)) ? 1 : 0;
}
int main() {
    scanf("%d", &n);
    for (int i = 0, a, b, c, d, e, f; i < n; i++) {
        scanf("%s %d:%d:%d %d:%d:%d", id[i], &a, &b, &c, &d, &e, &f);
        T tmp1 = { a, b, c }, tmp2 = { d, e, f };
        if (cmp(tmp1, MINN)) beg = i, MINN = tmp1;
        if (cmp(MAXN, tmp2)) en = i, MAXN = tmp2;
    }
    printf("%s %s", id[beg], id[en]);
    return 0;
}