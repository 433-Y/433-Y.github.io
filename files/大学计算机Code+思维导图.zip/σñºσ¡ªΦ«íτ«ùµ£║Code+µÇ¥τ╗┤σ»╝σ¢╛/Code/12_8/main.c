#include <stdio.h>
int IsPrime(int n) {
    int Judge = 1;
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) {
            Judge = 0; break;
        }
    }
    return Judge;
}
int main() {
    int m, n, sum = 0;
    scanf("%d%d", &m, &n);
    for (int i = m; i <= n - 2; i++)
        if (IsPrime(i) & IsPrime(i + 2)) sum ++;
    printf("%d", sum);
    return 0;
}
