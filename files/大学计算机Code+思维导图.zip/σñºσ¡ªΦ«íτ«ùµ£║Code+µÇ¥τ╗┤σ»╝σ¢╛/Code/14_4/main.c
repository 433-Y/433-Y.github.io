#include <stdio.h>
int n, k, vis[3005], cnt;
int main() {
    scanf("%d%d", &n, &k);
    int sum = n;
    while (sum > 1) for (int j = 0; j < n; j++) if (!vis[j]) if (++cnt % k == 0) vis[j] = 1, sum--;
    for (int i = 0; i < n; i++) if (!vis[i]) printf("%d", i + 1);
    return 0;
}
