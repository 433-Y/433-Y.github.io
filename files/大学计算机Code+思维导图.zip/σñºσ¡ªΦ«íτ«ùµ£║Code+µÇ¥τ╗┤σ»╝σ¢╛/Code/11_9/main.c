#include <stdio.h>
int n, beg, sum;
int main() {
    while (1) {
        scanf("%d", &n);
        if (!n) break;
        sum += n > beg ? 5 + (n - beg) * 6 : 5 + (beg - n) * 4;
        beg = n;
    }
    printf("%d\n", sum);
    return 0;
}
